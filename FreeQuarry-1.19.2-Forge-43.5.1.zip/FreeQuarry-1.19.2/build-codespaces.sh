#!/usr/bin/env bash
set -euo pipefail

# FreeQuarry build helper for GitHub Codespaces.
# Forge 1.19.2 + ForgeGradle 5.1 uses Gradle 7.5.1 and Java 17.

export JAVA_HOME="${JAVA_HOME:-/usr/lib/jvm/java-17-openjdk-amd64}"
if [[ ! -x "$JAVA_HOME/bin/java" ]]; then
  echo "Java 17 не найдена: $JAVA_HOME" >&2
  echo "Установи openjdk-17-jdk или укажи правильный JAVA_HOME." >&2
  exit 1
fi
export PATH="$JAVA_HOME/bin:$PATH"

GRADLE_BIN="${GRADLE_BIN:-$HOME/tools/gradle-7.5.1/bin/gradle}"
if [[ ! -x "$GRADLE_BIN" ]]; then
  if command -v gradle >/dev/null 2>&1; then
    GRADLE_BIN="$(command -v gradle)"
  else
    echo "Gradle не найден. Установи Gradle 7.5.1 в ~/tools/gradle-7.5.1." >&2
    exit 1
  fi
fi

GRADLE_VERSION="$($GRADLE_BIN --version | sed -n 's/^Gradle //p' | head -n 1)"
if [[ "$GRADLE_VERSION" != "7.5.1" ]]; then
  echo "Нужен Gradle 7.5.1, обнаружен: ${GRADLE_VERSION:-неизвестно}" >&2
  echo "Для ForgeGradle 5.1 версии Gradle 8+ не подходят." >&2
  exit 1
fi

cd "$(dirname "$0")"
"$GRADLE_BIN" --no-daemon clean build
echo
echo "Готовый мод: $(pwd)/build/libs/freequarry-1.1.0.jar"
