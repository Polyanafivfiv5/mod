@echo off
setlocal
java -version 2>&1 | findstr /C:"17." >nul
if errorlevel 1 (
  echo ERROR: Minecraft Forge 1.19.2 requires Java 17 for this project.
  echo Install a Java 17 JDK and set JAVA_HOME to it, then run this file again.
  pause
  exit /b 1
)
where gradle >nul 2>nul
if errorlevel 1 (
  echo ERROR: Gradle was not found. Install Gradle 7.5.1 or open this project in IntelliJ IDEA and import it as a Gradle project.
  pause
  exit /b 1
)
gradle build
if errorlevel 1 exit /b 1
echo.
echo Built mod: build\libs\freequarry-1.1.0.jar
pause
