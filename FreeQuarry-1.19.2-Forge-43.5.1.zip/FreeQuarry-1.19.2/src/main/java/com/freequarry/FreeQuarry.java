package com.freequarry;

import com.freequarry.block.QuarryBlock;
import com.freequarry.block.QuarryBlockEntity;
import com.freequarry.client.QuarryScreen;
import com.freequarry.menu.QuarryMenu;
import net.minecraft.world.inventory.MenuType;
import net.minecraft.world.item.BlockItem;
import net.minecraft.world.item.Item;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.entity.BlockEntityType;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.common.extensions.IForgeMenuType;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.fml.ModLoadingContext;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.config.ModConfig;
import net.minecraftforge.fml.event.lifecycle.FMLClientSetupEvent;
import net.minecraftforge.fml.javafmlmod.FMLJavaModLoadingContext;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod.EventBusSubscriber;

@Mod(FreeQuarry.MODID)
public class FreeQuarry {
    public static final String MODID = "freequarry";

    public static final DeferredRegister<Block> BLOCKS =
            DeferredRegister.create(ForgeRegistries.BLOCKS, MODID);
    public static final DeferredRegister<Item> ITEMS =
            DeferredRegister.create(ForgeRegistries.ITEMS, MODID);
    public static final DeferredRegister<BlockEntityType<?>> BLOCK_ENTITIES =
            DeferredRegister.create(ForgeRegistries.BLOCK_ENTITY_TYPES, MODID);
    public static final DeferredRegister<MenuType<?>> MENUS =
            DeferredRegister.create(ForgeRegistries.MENU_TYPES, MODID);

    public static final RegistryObject<Block> QUARRY = BLOCKS.register("quarry", () ->
            new QuarryBlock(BlockBehaviour.Properties.copy(Blocks.IRON_BLOCK).strength(3.5F)));

    public static final RegistryObject<Item> QUARRY_ITEM = ITEMS.register("quarry", () ->
            new BlockItem(QUARRY.get(), new Item.Properties()));

    public static final RegistryObject<BlockEntityType<QuarryBlockEntity>> QUARRY_BLOCK_ENTITY =
            BLOCK_ENTITIES.register("quarry", () ->
                    BlockEntityType.Builder.of(QuarryBlockEntity::new, QUARRY.get()).build(null));

    public static final RegistryObject<MenuType<QuarryMenu>> QUARRY_MENU = MENUS.register("quarry",
            () -> IForgeMenuType.create(QuarryMenu::new));

    public FreeQuarry() {
        IEventBus modBus = FMLJavaModLoadingContext.get().getModEventBus();
        BLOCKS.register(modBus);
        ITEMS.register(modBus);
        BLOCK_ENTITIES.register(modBus);
        MENUS.register(modBus);
    }

    @EventBusSubscriber(modid = MODID, bus = EventBusSubscriber.Bus.MOD, value = Dist.CLIENT)
    public static final class ClientEvents {
        @SubscribeEvent
        public static void onClientSetup(FMLClientSetupEvent event) {
            event.enqueueWork(() -> net.minecraft.client.gui.screens.MenuScreens.register(
                    QUARRY_MENU.get(), QuarryScreen::new));
        }
    }
}
