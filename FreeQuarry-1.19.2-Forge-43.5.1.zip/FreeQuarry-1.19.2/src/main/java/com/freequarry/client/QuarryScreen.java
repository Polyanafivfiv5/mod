package com.freequarry.client;

import com.freequarry.FreeQuarry;
import com.freequarry.menu.QuarryMenu;
import net.minecraft.client.gui.screens.inventory.AbstractContainerScreen;
import net.minecraft.network.chat.Component;
import net.minecraft.world.entity.player.Inventory;
import com.mojang.blaze3d.vertex.PoseStack;

public class QuarryScreen extends AbstractContainerScreen<QuarryMenu> {
    public QuarryScreen(QuarryMenu menu, Inventory playerInventory, Component title) {
        super(menu, playerInventory, title);
        this.imageWidth = 176;
        this.imageHeight = 238;
        this.titleLabelX = 8;
        this.titleLabelY = 6;
        this.inventoryLabelX = 8;
        this.inventoryLabelY = 137;
    }

    @Override
    protected void renderBg(PoseStack poseStack, float partialTick, int mouseX, int mouseY) {
        int left = leftPos;
        int top = topPos;
        // Background and simple industrial frame, drawn without an external GUI texture.
        fill(poseStack, left, top, left + imageWidth, top + imageHeight, 0xFF171B20);
        fill(poseStack, left + 2, top + 2, left + imageWidth - 2, top + imageHeight - 2, 0xFF343B43);
        fill(poseStack, left + 5, top + 5, left + imageWidth - 5, top + imageHeight - 5, 0xFF222830);
        fill(poseStack, left + 6, top + 17, left + imageWidth - 6, top + 135, 0xFF1A2026);
        fill(poseStack, left + 6, top + 146, left + imageWidth - 6, top + imageHeight - 6, 0xFF1A2026);
        fill(poseStack, left + 7, top + 15, left + imageWidth - 7, top + 16, 0xFFFFC533);
        fill(poseStack, left + 7, top + 144, left + imageWidth - 7, top + 145, 0xFF69737D);
    }

    @Override
    protected void renderLabels(PoseStack poseStack, int mouseX, int mouseY) {
        font.draw(poseStack, Component.translatable("screen.freequarry.storage"), 8, 6, 0xFFFFFF);
        font.draw(poseStack, Component.translatable("container.inventory"), 8, 137, 0xD5DADF);
    }
}
