package com.freequarry.block;

import com.freequarry.FreeQuarry;
import com.freequarry.menu.QuarryMenu;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.MenuProvider;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.inventory.AbstractContainerMenu;
import net.minecraft.world.inventory.ContainerLevelAccess;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraftforge.common.capabilities.Capability;
import net.minecraftforge.common.capabilities.ForgeCapabilities;
import net.minecraftforge.common.util.LazyOptional;
import net.minecraftforge.items.ItemStackHandler;
import net.minecraftforge.items.IItemHandler;
import javax.annotation.Nullable;
import java.util.List;
import java.util.Set;

public class QuarryBlockEntity extends BlockEntity implements MenuProvider {
    public static final int INVENTORY_SIZE = 54;
    private static final int AREA_SIZE = 64;
    private static final int TICKS_PER_BLOCK = 2;

    // These common terrain blocks are mined but their drops are discarded.
    private static final Set<Block> JUNK_BLOCKS = Set.of(
            Blocks.STONE, Blocks.COBBLESTONE, Blocks.DEEPSLATE, Blocks.COBBLED_DEEPSLATE,
            Blocks.GRANITE, Blocks.DIORITE, Blocks.ANDESITE, Blocks.TUFF, Blocks.CALCITE,
            Blocks.DRIPSTONE_BLOCK, Blocks.DIRT, Blocks.COARSE_DIRT, Blocks.ROOTED_DIRT,
            Blocks.GRASS_BLOCK, Blocks.PODZOL, Blocks.MYCELIUM, Blocks.DIRT_PATH,
            Blocks.GRAVEL, Blocks.SAND, Blocks.RED_SAND, Blocks.CLAY,
            Blocks.NETHERRACK, Blocks.BLACKSTONE, Blocks.BASALT, Blocks.END_STONE,
            Blocks.SOUL_SAND, Blocks.SOUL_SOIL, Blocks.MUD
    );

    private final ItemStackHandler inventory = new ItemStackHandler(INVENTORY_SIZE) {
        @Override
        protected void onContentsChanged(int slot) {
            setChanged();
        }
    };
    private LazyOptional<IItemHandler> itemHandler = LazyOptional.of(() -> inventory);

    private int scanX = 0;
    private int scanZ = 0;
    private int scanY;
    private int tickCounter = 0;
    private boolean finished = false;

    public QuarryBlockEntity(BlockPos pos, BlockState state) {
        super(FreeQuarry.QUARRY_BLOCK_ENTITY.get(), pos, state);
        this.scanY = pos.getY() - 1;
    }

    @Override
    public Component getDisplayName() {
        return Component.translatable("block.freequarry.quarry");
    }

    @Nullable
    @Override
    public AbstractContainerMenu createMenu(int id, Inventory playerInventory, Player player) {
        return new QuarryMenu(id, playerInventory,
                ContainerLevelAccess.create(level, worldPosition), inventory);
    }

    public ItemStackHandler getInventoryHandler() {
        return inventory;
    }

    public static void serverTick(Level level, BlockPos pos, BlockState state, QuarryBlockEntity quarry) {
        if (level.isClientSide || quarry.finished) return;

        if (++quarry.tickCounter < TICKS_PER_BLOCK) return;
        quarry.tickCounter = 0;

        if (quarry.scanY < level.getMinBuildHeight()) {
            quarry.finished = true;
            quarry.setChanged();
            return;
        }

        // Four-by-four chunk square, aligned to chunk borders, including the quarry's chunk.
        int chunkX = Math.floorDiv(pos.getX(), 16);
        int chunkZ = Math.floorDiv(pos.getZ(), 16);
        int minX = (chunkX - 1) * 16;
        int minZ = (chunkZ - 1) * 16;
        BlockPos target = new BlockPos(minX + quarry.scanX, quarry.scanY, minZ + quarry.scanZ);

        // Do not force-load chunks. Unloaded positions are skipped; later scan layers check again.
        if (!level.hasChunkAt(target)) {
            quarry.advanceCursor(level);
            return;
        }

        BlockState targetState = level.getBlockState(target);
        if (targetState.isAir() || !targetState.getFluidState().isEmpty()
                || targetState.getDestroySpeed(level, target) < 0
                || level.getBlockEntity(target) != null) {
            quarry.advanceCursor(level);
            return;
        }

        boolean junk = JUNK_BLOCKS.contains(targetState.getBlock());
        List<ItemStack> drops = junk ? List.of()
                : Block.getDrops(targetState, (ServerLevel) level, target, null);

        // When the storage is full, pause in front of this block instead of spilling items.
        if (!junk && !quarry.canStoreAll(drops)) return;

        level.setBlock(target, Blocks.AIR.defaultBlockState(), 3);
        if (!junk) quarry.storeAll(drops);
        quarry.advanceCursor(level);
        quarry.setChanged();
    }

    private boolean canStoreAll(List<ItemStack> drops) {
        ItemStackHandler simulation = new ItemStackHandler(INVENTORY_SIZE);
        simulation.deserializeNBT(inventory.serializeNBT());
        for (ItemStack drop : drops) {
            ItemStack remaining = drop.copy();
            for (int slot = 0; slot < simulation.getSlots() && !remaining.isEmpty(); slot++) {
                remaining = simulation.insertItem(slot, remaining, false);
            }
            if (!remaining.isEmpty()) return false;
        }
        return true;
    }

    private void storeAll(List<ItemStack> drops) {
        for (ItemStack drop : drops) {
            ItemStack remaining = drop.copy();
            for (int slot = 0; slot < inventory.getSlots() && !remaining.isEmpty(); slot++) {
                remaining = inventory.insertItem(slot, remaining, false);
            }
        }
    }

    private void advanceCursor(Level level) {
        scanX++;
        if (scanX >= AREA_SIZE) {
            scanX = 0;
            scanZ++;
            if (scanZ >= AREA_SIZE) {
                scanZ = 0;
                scanY--;
                if (scanY < level.getMinBuildHeight()) finished = true;
            }
        }
        setChanged();
    }

    @Override
    protected void saveAdditional(CompoundTag tag) {
        super.saveAdditional(tag);
        tag.put("Inventory", inventory.serializeNBT());
        tag.putInt("ScanX", scanX);
        tag.putInt("ScanZ", scanZ);
        tag.putInt("ScanY", scanY);
        tag.putInt("TickCounter", tickCounter);
        tag.putBoolean("Finished", finished);
    }

    @Override
    public void load(CompoundTag tag) {
        super.load(tag);
        if (tag.contains("Inventory")) inventory.deserializeNBT(tag.getCompound("Inventory"));
        scanX = tag.getInt("ScanX");
        scanZ = tag.getInt("ScanZ");
        scanY = tag.contains("ScanY") ? tag.getInt("ScanY") : worldPosition.getY() - 1;
        tickCounter = tag.getInt("TickCounter");
        finished = tag.getBoolean("Finished");
    }

    @Override
    public <T> LazyOptional<T> getCapability(Capability<T> capability, @Nullable Direction side) {
        if (capability == ForgeCapabilities.ITEM_HANDLER) return itemHandler.cast();
        return super.getCapability(capability, side);
    }

    @Override
    public void invalidateCaps() {
        super.invalidateCaps();
        itemHandler.invalidate();
    }
}
