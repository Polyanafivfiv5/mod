package com.freequarry.menu;

import com.freequarry.FreeQuarry;
import com.freequarry.block.QuarryBlockEntity;
import net.minecraft.core.BlockPos;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.inventory.AbstractContainerMenu;
import net.minecraft.world.inventory.ContainerLevelAccess;
import net.minecraft.world.inventory.Slot;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraftforge.items.IItemHandler;
import net.minecraftforge.items.ItemStackHandler;
import net.minecraftforge.items.SlotItemHandler;

public class QuarryMenu extends AbstractContainerMenu {
    public static final int QUARRY_SLOTS = QuarryBlockEntity.INVENTORY_SIZE;
    private final ContainerLevelAccess access;

    // Used by the client menu factory. The server's menu is supplied by the block entity.
    public QuarryMenu(int id, Inventory playerInventory, FriendlyByteBuf data) {
        this(id, playerInventory, data.readBlockPos());
    }

    private QuarryMenu(int id, Inventory playerInventory, BlockPos pos) {
        this(id, playerInventory, ContainerLevelAccess.create(playerInventory.player.level, pos),
                getClientHandler(playerInventory, pos));
    }

    public QuarryMenu(int id, Inventory playerInventory, ContainerLevelAccess access, IItemHandler quarryInventory) {
        super(FreeQuarry.QUARRY_MENU.get(), id);
        this.access = access;

        // Quarry storage: 6 rows x 9 columns = 54 slots.
        for (int row = 0; row < 6; row++) {
            for (int column = 0; column < 9; column++) {
                addSlot(new SlotItemHandler(quarryInventory, column + row * 9,
                        8 + column * 18, 24 + row * 18));
            }
        }

        // Player inventory (27 slots).
        for (int row = 0; row < 3; row++) {
            for (int column = 0; column < 9; column++) {
                addSlot(new Slot(playerInventory, column + row * 9 + 9,
                        8 + column * 18, 151 + row * 18));
            }
        }

        // Player hotbar (9 slots).
        for (int column = 0; column < 9; column++) {
            addSlot(new Slot(playerInventory, column, 8 + column * 18, 209));
        }
    }

    private static IItemHandler getClientHandler(Inventory playerInventory, BlockPos pos) {
        BlockEntity blockEntity = playerInventory.player.level.getBlockEntity(pos);
        if (blockEntity instanceof QuarryBlockEntity quarry) return quarry.getInventoryHandler();
        return new ItemStackHandler(QUARRY_SLOTS);
    }

    @Override
    public ItemStack quickMoveStack(Player player, int index) {
        Slot slot = slots.get(index);
        if (!slot.hasItem()) return ItemStack.EMPTY;

        ItemStack original = slot.getItem();
        ItemStack copy = original.copy();

        if (index < QUARRY_SLOTS) {
            if (!moveItemStackTo(original, QUARRY_SLOTS, slots.size(), true)) return ItemStack.EMPTY;
        } else {
            if (!moveItemStackTo(original, 0, QUARRY_SLOTS, false)) return ItemStack.EMPTY;
        }

        if (original.isEmpty()) slot.set(ItemStack.EMPTY);
        else slot.setChanged();
        slot.onTake(player, original);
        return copy;
    }

    @Override
    public boolean stillValid(Player player) {
        return stillValid(access, player, FreeQuarry.QUARRY.get());
    }
}
